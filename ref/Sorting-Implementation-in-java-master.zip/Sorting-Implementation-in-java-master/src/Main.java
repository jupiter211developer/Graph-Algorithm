public class Main {

    public static void main(String[] args){

        MergeSort obj = new MergeSort();
        obj.MergeSort(0,5);
        obj.display();
    }
}
